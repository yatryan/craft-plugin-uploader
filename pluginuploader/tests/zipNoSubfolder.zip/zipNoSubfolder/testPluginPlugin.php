<?php
namespace Craft;

class TestPluginPlugin extends BasePlugin
{
    public function getName()
    {
         return Craft::t('Test Plugin');
    }

    public function getVersion()
    {
        return '1.0.0';
    }
}
